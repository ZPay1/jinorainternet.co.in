
# from django.contrib import admin
# from django.urls import path
# from . import views
# # Recharge pages url  =========================================
# path('mobile-prepaid/', views.mobile_prepaid_view, name='mobile_prepaid'),

from django.urls import path
from . import views  # <-- same app ke views import karo

urlpatterns = [


    path('mobile-prepaid/', views.mobile_prepaid_view, name='mobile_prepaid'),
    # path('recharge-success/', views.recharge_success_view, name='recharge_success'),
    path('mobile-postpaid/', views.mobile_postpaid_view, name='mobile_postpaid'),
    path('dth-recharge/', views.dth_recharge_view, name='dth_recharge'),
    path('fastag-recharge/', views.fastag_recharge_view, name='fastag_recharge'),
    path('electricity-bill/', views.electricity_bill_view, name='electricity_bill'),
    path('transaction-hisotry/', views.transaction_history_view, name='transaction_hisotry'),
    
    
    
     
    path('', views.recharge_view, name='recharge_view'),
    
    
    
]
